import pymupdf4llm
import pymupdf
import re
import os
import json

def run_extraction(pdf_path: str, output_json_path: str, image_output_dir: str) -> bool:
    """
    Extracts text, Markdown tables, and takes high-res screenshots of 
    visual tables and charts, packaging everything into a JSON dictionary.
    """
    if not os.path.exists(pdf_path):
        print(f"[Extractor] Error: Could not find '{pdf_path}'.")
        return False

    os.makedirs(image_output_dir, exist_ok=True)
    print(f"[Extractor] Processing: '{pdf_path}'...")
    
    # ---------------------------------------------------------
    # PART A: Extract Tables as Crisp PNG Images
    # ---------------------------------------------------------
    try:
        doc = pymupdf.open(pdf_path)
        for page_num in range(len(doc)):
            page = doc[page_num]
            tables = page.find_tables()
            
            for table_index, table in enumerate(tables.tables):
                bbox = table.bbox 
                # Take a high-res screenshot of just the table's bounding box
                pix = page.get_pixmap(clip=bbox, dpi=300)
                
                table_filename = f"table_page{page_num + 1}_{table_index + 1}.png"
                table_filepath = os.path.join(image_output_dir, table_filename)
                pix.save(table_filepath)
                
        print(f"[Extractor] Visual table extraction complete.")
    except Exception as e:
        print(f"[Extractor] Warning: Table screenshot extraction encountered an issue: {e}")

    # ---------------------------------------------------------
    # PART B: Extract Text, Charts, and Markdown structure
    # ---------------------------------------------------------
    try:
        md_text = pymupdf4llm.to_markdown(
            pdf_path,
            write_images=True,
            image_path=image_output_dir,
            image_format="png",
            dpi=300,
            header=False,
            footer=False
        )
    except Exception as e:
        print(f"[Extractor] Error during Markdown extraction: {e}")
        return False
    
    # ---------------------------------------------------------
    # PART C: Parse Markdown into a Structured Dictionary
    # ---------------------------------------------------------
    header_pattern = r'(?m)^(#+\s+.*|[\*\_]+[\d\.]+(?:[\*\_]|\s)+[^\n]*|[\*\_]+(?:Acknowledgments|References)[\*\_]*[^\n]*|[IVXLC]+\.?\s+[A-Z][A-Z ]+)'
    parts = re.split(header_pattern, md_text, flags=re.IGNORECASE)
    paper_dict = {}
    
    if len(parts) > 1:
        # Map the Paper Title
        raw_title = parts[1]
        title_content = parts[2].strip() if 2 < len(parts) else ""
        clean_title = re.sub(r'^#+\s+', '', raw_title).replace('**', '').replace('_', '').strip()
        paper_dict["Paper Title"] = clean_title
        
        # Map the Front Matter (Authors, Abstract, etc.)
        if title_content:
            paper_dict["Front Matter"] = title_content
            
        # Loop through remaining sections
        for i in range(3, len(parts), 2):
            raw_header = parts[i]
            content = parts[i+1].strip() if i+1 < len(parts) else ""
            
            clean_header = re.sub(r'^[IVXLC]+\.?\s+', '', raw_header)
            clean_header = re.sub(r'^#+\s+', '', clean_header).replace('**', '').replace('_', '').strip()
            
            if clean_header in paper_dict:
                paper_dict[clean_header] += "\n\n" + content
            else:
                paper_dict[clean_header] = content
                
    # ---------------------------------------------------------
    # PART D: Export to JSON
    # ---------------------------------------------------------
    os.makedirs(os.path.dirname(output_json_path), exist_ok=True)
    try:
        with open(output_json_path, "w", encoding="utf-8") as json_file:
            json.dump(paper_dict, json_file, ensure_ascii=False, indent=4)
        print(f"[Extractor] Success! Data structured and saved to '{output_json_path}'.")
        return True
    except Exception as e:
        print(f"[Extractor] Failed to write JSON: {e}")
        return False